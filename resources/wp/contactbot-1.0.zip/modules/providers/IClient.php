<?php

/**
 * Interface IClient
 *
 * Our base messaging interface
 */
interface IClient
{
    public function send($message, $target);

    public function getHistory($offset = null);

    public function findAdminVerificationMessage($messages);
}
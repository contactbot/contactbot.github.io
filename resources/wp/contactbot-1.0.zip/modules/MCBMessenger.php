<?php

/**
 * The MCB messenger
 *
 * This class provides an abstract interface to access
 * the different messaging clients (e.g. Telegram, Messenger, etc.)
 */

// Load interface
require_once MCB_PLUGIN_DIR . '/modules/providers/IClient.php';

// Load providers (FB Messenger coming soon)
require_once MCB_PLUGIN_DIR . '/modules/providers/MCBTelegramClient.php';

class MCBMessenger
{
    const TYPE_TELEGRAM = 'telegram';
    const TYPE_MESSENGER = 'fb-messenger';

    // Where we keep a reference to the admin
    public static $admin = null;

    /**
     * @param $type: telegram, fb-messenger, etc.
     */
    public static function verifyAdmin($type) {
        if ($type == self::TYPE_TELEGRAM) {
            $client = MCBTelegramClient::instance();

            // Get updates
            try {
                $updates = $client->getHistory();
            }
            catch (Exception $e) {
                return ['error' => $e->getMessage(), 'errorCode' => 9999];
            }
            if ($updates->ok && count($updates->result) > 0) {

                // Admin is confirming registration
                // Let's find the admin message
                if ($admin = $client->findAdminVerificationMessage($updates->result)) {
                    // Store in database
                    MCBUtils::save_settings_item('admin', $admin);

                    // Store in instance so we don't have to fetch it
                    self::$admin = $admin;
                }
                else {
                    return ['error' => 'failed to verify admin', 'errorCode' => 700];
                }
            }
            else {
                return ['error' => 'failed to get new updates for admin verification', 'errorCode' => 704];
            }
        }

        return [];
    }

    /**
     * Handle an incoming message
     *
     * @param $from: the user id or alias
     * @param $message
     * @return mixed|null|string
     * @throws Exception
     */
    public static function handle_message(MCBUser $session_user, $message) {

        // Get selected client
        // If selected client is Telegram
        $client = MCBTelegramClient::instance();

        $from = $session_user->getUsername();
        $data = [
            'chat_id' => self::getAdmin()['id'],
            'text' =>  "$from -> {$message['text']}",
            'src' => $message['src'],
            'offset' => 0
        ];

        // TODO: increment offset if needed


        $result = null;
        try {
            $result = $client->send($data);
        }
        catch (Exception $e) {
            $result = $e->getMessage();
        }

        return $result;
    }

    /**
     * Get the latest bot updates
     *
     * @param MCBUser $session_user
     * @return array
     * @throws Exception
     */
    public static function getUpdates(MCBUser $session_user) {
        $type = self::TYPE_TELEGRAM; // TODO: get from options (selected client)

        if ($type == self::TYPE_TELEGRAM) {
            $client = MCBTelegramClient::instance();

            // Get updates
            $offset = $session_user->getTelegramOffset() ? $session_user->getTelegramOffset() : 0;
            $offset = $offset > 0 ? $offset + 1 : 0;
            $updates = $client->getHistory($offset);
            if ($updates->ok && count($updates->result) > 0) {
                // We have updates, let's filter out updates
                // that are not directed at this user
                $username = $session_user->getUsername() . ':';
                $results = array_filter($updates->result, function ($r) use ($username) {
                    if (strpos($r->message->text, $username) === 0) {
                        // We got a match
                        $r->src = 'admin';

                        // Remove session string
                        $r->message->text = trim(str_replace($username, '', $r->message->text));
                        return $r;
                    }
                    echo '';
                });

                // Get offset
                $offset = max(array_map(function($r) {
                    return $r->update_id;
                }, $results));

                $s = MCBSession::instance();
                $s->setTelegramOffset($offset);

                return $results;
            }
        }
    }

    /**
     * Returns the selected admin
     *
     * @return bool|null
     * @throws Exception
     */
    private static function getAdmin() {
        // Check if we have it in our static variable
        if (self::$admin) return self::$admin;

        // No, we don't. Let's fetch from our database
        $admin = MCBUtils::get_settings_item('admin');
        if ($admin) {
            self::$admin = $admin;
            return $admin;
        }
        else {
            throw new Exception("No contact bot admin");
        }
    }
}
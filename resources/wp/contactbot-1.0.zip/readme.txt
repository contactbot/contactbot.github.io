=== Contact Bot ===
Contributors: ty_pwd
Tags: contact, form, contact form, bot, chatbot, chat, messaging, contact bot, chat bot, ai, telegram, messenger platform
Requires at least: 4.3
Tested up to: 4.5
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A simple and friendly contact bot

== Description ==

"We think you should message a business just the way you would message a friend," Mark Zuckerberg said on stage at f8.

The Contact Bot plugin allows you to create your own, personal messaging bot.

This day,

== Installation ==

1. Upload the entire `contactbot` folder to the `/wp-content/plugins/` directory.
1. Activate the plugin through the 'Plugins' menu in WordPress.

You will find 'Contact Bot' menu in your WordPress admin panel. Configure your bot and MAKE SURE YOU READ THE "How to user" section.

== Screenshots ==

1. screenshot-1.jpg
1. screenshot-2.jpg
1. screenshot-3.jpg

== Changelog ==

= 1.0 =

* Initial release

<?php

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) )
	exit();

function mcb_delete_plugin() {
	
	// TODO: for when we have stuff to remove
}

mcb_delete_plugin();

?>
/**
 * Admin side AngularJS app
 */
var mcbAdminApp = angular.module('mcbAdminApp', []);

mcbAdminApp.controller('AdminCtrl', function($scope, Api) {

    $scope.UNKNOWN_ERROR_CODE = 9999;
    $scope.INVALID_TOKEN_ERROR_CODE = 800;
    $scope.ADMIN_VERIFICATION_FAILED_ERROR_CODE = 700;
    $scope.GET_UPDATES_FAILED_ERROR_CODE = 704;

    $scope.loading =  {
        verifyTelegram: false,
        storeTelegramToken: false
    };

    $scope.data = {
        messagingClient: "telegram"
    };

    $scope.errors = {
        telegramVerificationError: false
    };

    $scope.telegramInvalidated = false;
    $scope.telegramVerified = false;

    $scope.toggleTelegramConfig = function(state) {
        $scope.editTelegramConfig = state;
    };

    /**
     * Verify the Telegram token and email
     */
    $scope.verifyTelegram = function() {
        console.log("Verify telegram");
        $scope.telegramInvalidated = true;

        $scope.loading.verifyTelegram = true;
        $scope.errors.telegramVerificationError = false;
        $scope.telegramVerified = false;

        Api.verifyTelegram().then(function(response) {
            console.log("VERIFY TELEGRAM RES:", response);
            $scope.telegramVerified = true;
        }, function(error) {
            console.warn("TELEGRAM VERIFICATION FAILED:", error);
            if (error.data && error.data.data && error.data.data.errorCode) {
                $scope.errors.telegramVerificationError = error.data.data.errorCode;
            }
            else {
                $scope.errors.telegramVerificationError = $scope.UNKNOWN_ERROR_CODE;
            }
        }).finally(function() {
            $scope.loading.verifyTelegram = false;
        });
    };

    /**
     * Store the Telegram token in the database
     */
    $scope.tokenStored = false;
    $scope.storeTelegramToken = function(token) {

        if (!$scope.mcbGeneralSettingsForm.$valid || !token || token.length < 1) {
            $scope.errors.telegramTokenStoreError = $scope.INVALID_TOKEN_ERROR_CODE;
            return;
        }

        $scope.telegramInvalidated = true;

        console.log("Store Telegram token", token);

        $scope.tokenStored = false;
        $scope.loading.storeTelegramToken = true;
        $scope.errors.telegramTokenStoreError = false;

        Api.storeTelegramToken(token).then(function(response) {
            console.log("TELEGRAM TOKEN STORE RES:", response);
            $scope.tokenStored = true;
        }, function(error) {
            console.warn("TELEGRAM TOKEN STORE FAILED:", error);
        }).finally(function() {
            $scope.loading.storeTelegramToken = false;
        });
    }

});

mcbAdminApp.controller('HowToUseCtrl', function($scope) {
    $scope.test = 'how-to-se';
});


mcbAdminApp.factory('Api', function($http, $httpParamSerializerJQLike) {

    var wpRequest = function(action, data) {

        // Fetched globally from WP
        var url = ajaxurl;

        var payload = {
            data: data,
            action: action
        };

        return $http({
            url: url,
            method: 'POST',
            data: $httpParamSerializerJQLike(payload), // Make sure to inject the service you choose to the controller
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded' // Note the appropriate header
            }
        });
    };

    return {
        verifyTelegram: function() {
            return wpRequest('mcb_verify_telegram');
        },

        storeTelegramToken: function(token) {
            return wpRequest('mcb_store_telegram_token', token);
        }
    }
});